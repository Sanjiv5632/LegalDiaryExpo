import * as SQLite from 'expo-sqlite';

let db;

export const getDatabase = async () => {
  if (!db) {
    db = await SQLite.openDatabaseAsync('legal_diary.db');
    await initDatabase(db);
  }
  return db;
};

const initDatabase = async (database) => {
  await database.execAsync(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS case_entries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      dateKey TEXT NOT NULL,
      caseUniqueId TEXT NOT NULL,
      serialNo INTEGER DEFAULT 0,
      previousDate TEXT DEFAULT '',
      courtName TEXT DEFAULT '',
      plaintiffName TEXT DEFAULT '',
      defendantName TEXT DEFAULT '',
      caseNo TEXT DEFAULT '',
      caseYear TEXT DEFAULT '',
      policeStation TEXT DEFAULT '',
      nextProceedings TEXT DEFAULT '',
      nextDate TEXT DEFAULT '',
      lastModified INTEGER DEFAULT 0,
      futureEntryCreated INTEGER DEFAULT 0,
      isActive INTEGER DEFAULT 1
    );

    CREATE INDEX IF NOT EXISTS idx_dateKey ON case_entries(dateKey);
    CREATE INDEX IF NOT EXISTS idx_caseUniqueId ON case_entries(caseUniqueId);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_date_case ON case_entries(dateKey, caseUniqueId);
  `);
};

// ── INSERT ────────────────────────────────────────────────────────────────────
export const insertCase = async (entry) => {
  const database = await getDatabase();
  const now = Date.now();
  try {
    const result = await database.runAsync(
      `INSERT OR IGNORE INTO case_entries 
        (dateKey, caseUniqueId, serialNo, previousDate, courtName, plaintiffName, 
         defendantName, caseNo, caseYear, policeStation, nextProceedings, nextDate, 
         lastModified, isActive)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`,
      [entry.dateKey, entry.caseUniqueId, entry.serialNo || 0,
       entry.previousDate || '', entry.courtName || '', entry.plaintiffName || '',
       entry.defendantName || '', entry.caseNo || '', entry.caseYear || '',
       entry.policeStation || '', entry.nextProceedings || '', entry.nextDate || '', now]
    );
    return result.lastInsertRowId;
  } catch (e) {
    console.error('insertCase error:', e);
    return -1;
  }
};

// ── UPDATE ────────────────────────────────────────────────────────────────────
export const updateCase = async (entry) => {
  const database = await getDatabase();
  await database.runAsync(
    `UPDATE case_entries SET
      courtName=?, plaintiffName=?, defendantName=?, caseNo=?, caseYear=?,
      policeStation=?, nextProceedings=?, nextDate=?, previousDate=?,
      lastModified=?, futureEntryCreated=?, isActive=?
     WHERE id=?`,
    [entry.courtName || '', entry.plaintiffName || '', entry.defendantName || '',
     entry.caseNo || '', entry.caseYear || '', entry.policeStation || '',
     entry.nextProceedings || '', entry.nextDate || '', entry.previousDate || '',
     Date.now(), entry.futureEntryCreated ? 1 : 0, entry.isActive ? 1 : 0, entry.id]
  );
};

// ── DELETE ────────────────────────────────────────────────────────────────────
export const deleteCase = async (id) => {
  const database = await getDatabase();
  await database.runAsync('DELETE FROM case_entries WHERE id=?', [id]);
};

// ── QUERIES ───────────────────────────────────────────────────────────────────
export const getCasesForDate = async (dateKey) => {
  const database = await getDatabase();
  return await database.getAllAsync(
    'SELECT * FROM case_entries WHERE dateKey=? ORDER BY serialNo ASC', [dateKey]
  );
};

export const getAllDatesWithCases = async () => {
  const database = await getDatabase();
  const rows = await database.getAllAsync(
    'SELECT DISTINCT dateKey FROM case_entries ORDER BY dateKey ASC'
  );
  return rows.map(r => r.dateKey);
};

export const getMaxSerialNo = async (dateKey) => {
  const database = await getDatabase();
  const row = await database.getFirstAsync(
    'SELECT COALESCE(MAX(serialNo),0) as maxNo FROM case_entries WHERE dateKey=?', [dateKey]
  );
  return row?.maxNo || 0;
};

export const getCaseByUniqueIdAndDate = async (caseUniqueId, dateKey) => {
  const database = await getDatabase();
  return await database.getFirstAsync(
    'SELECT * FROM case_entries WHERE caseUniqueId=? AND dateKey=?',
    [caseUniqueId, dateKey]
  );
};

export const markFutureEntryCreated = async (id) => {
  const database = await getDatabase();
  await database.runAsync(
    'UPDATE case_entries SET futureEntryCreated=1, lastModified=? WHERE id=?',
    [Date.now(), id]
  );
};

export const getTotalCasesCount = async () => {
  const database = await getDatabase();
  const row = await database.getFirstAsync(
    'SELECT COUNT(DISTINCT caseUniqueId) as total FROM case_entries'
  );
  return row?.total || 0;
};

export const getActiveCasesCount = async () => {
  const database = await getDatabase();
  const row = await database.getFirstAsync(
    `SELECT COUNT(DISTINCT caseUniqueId) as active FROM case_entries 
     WHERE isActive=1 AND (nextDate='' OR nextDate IS NULL OR nextDate >= date('now'))`
  );
  return row?.active || 0;
};

// Feature 3: Monthly summary - per day case count
export const getMonthlySummary = async (yearMonth) => {
  const database = await getDatabase();
  return await database.getAllAsync(
    `SELECT dateKey, 
            COUNT(*) as caseCount,
            GROUP_CONCAT(plaintiffName || ' vs ' || defendantName, ' | ') as parties
     FROM case_entries 
     WHERE substr(dateKey,1,7)=?
     GROUP BY dateKey
     ORDER BY dateKey ASC`,
    [yearMonth]
  );
};

// Feature 5: Active cases list
export const getActiveCasesList = async () => {
  const database = await getDatabase();
  return await database.getAllAsync(
    `SELECT * FROM case_entries 
     WHERE isActive=1 AND nextDate != '' AND nextDate >= date('now','localtime')
     ORDER BY nextDate ASC`
  );
};

export const getAllCasesList = async () => {
  const database = await getDatabase();
  return await database.getAllAsync(
    `SELECT c1.* FROM case_entries c1
     INNER JOIN (
       SELECT caseUniqueId, MAX(dateKey) as maxDate 
       FROM case_entries GROUP BY caseUniqueId
     ) c2 ON c1.caseUniqueId=c2.caseUniqueId AND c1.dateKey=c2.maxDate
     ORDER BY c1.lastModified DESC`
  );
};
