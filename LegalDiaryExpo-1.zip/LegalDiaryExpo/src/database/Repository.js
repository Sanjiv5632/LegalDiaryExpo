import * as DB from './Database';
import { generateUUID } from '../utils/helpers';

// ── CREATE new case (first in chain) ─────────────────────────────────────────
export const createNewCase = async (dateKey) => {
  const serialNo = (await DB.getMaxSerialNo(dateKey)) + 1;
  const entry = {
    dateKey,
    caseUniqueId: generateUUID(),
    serialNo,
    previousDate: '',
    courtName: '', plaintiffName: '', defendantName: '',
    caseNo: '', caseYear: '', policeStation: '',
    nextProceedings: '', nextDate: '', isActive: 1,
  };
  const id = await DB.insertCase(entry);
  return { ...entry, id };
};

// ── SAVE case + auto-link to next date ───────────────────────────────────────
export const saveCase = async (entry) => {
  await DB.updateCase(entry);
  
  if (entry.nextDate && entry.nextDate.trim() !== '') {
    // Prevent circular link
    if (entry.nextDate === entry.dateKey) return;
    await createLinkedFutureEntry(entry);
  }
};

// Feature 4: Auto-copy ALL case details to next date
// Only nextDate and nextProceedings need to be updated on that future date
const createLinkedFutureEntry = async (sourceEntry) => {
  const futureDate = sourceEntry.nextDate;
  
  const existing = await DB.getCaseByUniqueIdAndDate(sourceEntry.caseUniqueId, futureDate);
  
  if (!existing) {
    // Create complete copy with all details pre-filled
    const serialNo = (await DB.getMaxSerialNo(futureDate)) + 1;
    const linkedEntry = {
      dateKey: futureDate,
      caseUniqueId: sourceEntry.caseUniqueId,
      serialNo,
      previousDate: sourceEntry.dateKey,       // back-link to current date
      // ── All fields copied automatically ──
      courtName: sourceEntry.courtName,
      plaintiffName: sourceEntry.plaintiffName,
      defendantName: sourceEntry.defendantName,
      caseNo: sourceEntry.caseNo,
      caseYear: sourceEntry.caseYear,
      policeStation: sourceEntry.policeStation,
      nextProceedings: sourceEntry.nextProceedings, // user will update this
      nextDate: '',                              // user will set next hearing
      isActive: 1,
      futureEntryCreated: false,
    };
    await DB.insertCase(linkedEntry);
  } else {
    // Update only header fields, preserve any edits user made
    await DB.updateCase({
      ...existing,
      previousDate: sourceEntry.dateKey,
      courtName: sourceEntry.courtName,
      plaintiffName: sourceEntry.plaintiffName,
      defendantName: sourceEntry.defendantName,
      caseNo: sourceEntry.caseNo,
      caseYear: sourceEntry.caseYear,
      policeStation: sourceEntry.policeStation,
    });
  }
  
  // Mark source as having created future entry
  await DB.markFutureEntryCreated(sourceEntry.id);
};

export const deleteCase = async (id) => await DB.deleteCase(id);
export const getCasesForDate = async (dateKey) => await DB.getCasesForDate(dateKey);
export const getAllDatesWithCases = async () => await DB.getAllDatesWithCases();
export const getTotalCasesCount = async () => await DB.getTotalCasesCount();
export const getActiveCasesCount = async () => await DB.getActiveCasesCount();
export const getMonthlySummary = async (yearMonth) => await DB.getMonthlySummary(yearMonth);
export const getActiveCasesList = async () => await DB.getActiveCasesList();
export const getAllCasesList = async () => await DB.getAllCasesList();
