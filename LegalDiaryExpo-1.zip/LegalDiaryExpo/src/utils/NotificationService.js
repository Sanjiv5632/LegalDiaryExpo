import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import { getCasesForDate } from '../database/Repository';
import { tomorrowKey, formatDate } from './helpers';

// ── Notification behavior when app is foregrounded ────────────────────────────
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

const CHANNEL_ID = 'legal_diary_reminders';

// ── Setup notification channel (Android) ─────────────────────────────────────
export const setupNotificationChannel = async () => {
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync(CHANNEL_ID, {
      name: 'Court Hearing Reminders',
      importance: Notifications.AndroidImportance.HIGH,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#1A237E',
      sound: true,
    });
  }
};

// ── Request permission ────────────────────────────────────────────────────────
export const requestNotificationPermission = async () => {
  if (!Device.isDevice) return false; // Emulator skip

  const { status: existing } = await Notifications.getPermissionsAsync();
  if (existing === 'granted') return true;

  const { status } = await Notifications.requestPermissionsAsync();
  return status === 'granted';
};

// ── Cancel all existing reminders before rescheduling ────────────────────────
export const cancelAllReminders = async () => {
  await Notifications.cancelAllScheduledNotificationsAsync();
};

// ── Schedule daily 5 PM reminder ─────────────────────────────────────────────
export const scheduleDailyReminder = async () => {
  await cancelAllReminders();

  const granted = await requestNotificationPermission();
  if (!granted) return false;

  await setupNotificationChannel();

  // Schedule recurring trigger at 17:00 every day
  await Notifications.scheduleNotificationAsync({
    content: {
      title: '⚖️ LegalDiary — Kal ke Mukadme',
      body: 'Kal ke court hearings check karein.',
      data: { type: 'daily_reminder' },
      sound: true,
      priority: Notifications.AndroidNotificationPriority.HIGH,
    },
    trigger: {
      channelId: CHANNEL_ID,
      hour: 17,
      minute: 0,
      repeats: true,
    },
  });

  return true;
};

// ── Send immediate notifications for tomorrow's cases ────────────────────────
// Called when notification is received (via listener in App.js)
export const sendTomorrowCaseNotifications = async () => {
  const tomorrow = tomorrowKey();
  const cases = await getCasesForDate(tomorrow);

  if (cases.length === 0) return;

  // Group notification (summary)
  if (cases.length > 1) {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: `⚖️ Kal ${cases.length} Mukadme Hain`,
        body: `${formatDate(tomorrow)} ko ${cases.length} court hearings scheduled hain.`,
        data: { dateKey: tomorrow },
        priority: Notifications.AndroidNotificationPriority.HIGH,
      },
      trigger: null, // immediate
    });
  }

  // Individual per-case notifications
  for (const c of cases.slice(0, 3)) {
    const vs = c.plaintiffName && c.defendantName
      ? `${c.plaintiffName} vs ${c.defendantName}`
      : c.courtName || 'Case';

    await Notifications.scheduleNotificationAsync({
      content: {
        title: `🏛 ${c.courtName || 'Court'} — ${formatDate(tomorrow)}`,
        body: `${vs}\nCase: ${c.caseNo || '?'}/${c.caseYear || '?'}\n${c.nextProceedings || ''}`.trim(),
        data: { dateKey: tomorrow, caseId: c.id },
        priority: Notifications.AndroidNotificationPriority.HIGH,
      },
      trigger: null, // immediate
    });
  }
};
