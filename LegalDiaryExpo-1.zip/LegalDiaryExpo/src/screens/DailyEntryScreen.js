import React, { useState, useCallback } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, FlatList, TextInput,
  Alert, Share, ActivityIndicator, Platform
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { getCasesForDate, createNewCase, saveCase, deleteCase } from '../database/Repository';
import { generateDailyPDF, generateDateShareText } from '../utils/pdfGenerator';
import { formatDate, todayKey, isValidNextDate } from '../utils/helpers';

const COLORS = { primary: '#1A237E', error: '#C62828', background: '#F3F4F9' };

export default function DailyEntryScreen({ route, navigation }) {
  const { dateKey } = route.params;
  const [cases, setCases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  // ── KEY FIX: useFocusEffect reloads every time screen is focused ──────────
  useFocusEffect(
    useCallback(() => {
      let active = true;
      const load = async () => {
        setLoading(true);
        try {
          const data = await getCasesForDate(dateKey);
          if (active) setCases(data);
        } catch (e) { console.error(e); }
        finally { if (active) setLoading(false); }
      };
      load();
      return () => { active = false; }; // cleanup on unmount
    }, [dateKey])
  );

  const refreshCases = async () => {
    const data = await getCasesForDate(dateKey);
    setCases(data);
  };

  const handleAddCase = async () => {
    const newCase = await createNewCase(dateKey);
    // Immediately add to local state — no need to reload
    setCases(prev => [...prev, newCase]);
  };

  const handleSaveCase = async (updatedCase) => {
    await saveCase(updatedCase);
    // Refresh list to show linked entry changes
    await refreshCases();
  };

  const handleDeleteCase = (id) => {
    Alert.alert('Delete Entry', 'Permanently delete this case entry?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => {
        await deleteCase(id);
        setCases(prev => prev.filter(c => c.id !== id));
      }},
    ]);
  };

  const handleShareText = async () => {
    const text = generateDateShareText(dateKey, cases);
    await Share.share({ message: text, title: `Cases — ${formatDate(dateKey)}` });
  };

  const handleGeneratePDF = async () => {
    setGenerating(true);
    try { await generateDailyPDF(dateKey, cases); }
    catch (e) { Alert.alert('Error', 'Could not generate PDF.'); }
    finally { setGenerating(false); }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color="#fff" />
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerDate}>{formatDate(dateKey)}</Text>
          {dateKey === todayKey() && <Text style={styles.headerSub}>Today</Text>}
        </View>
        <Text style={styles.caseCount}>{cases.length} case{cases.length !== 1 ? 's' : ''}</Text>
        <TouchableOpacity onPress={handleShareText} style={styles.iconBtn}>
          <Ionicons name="share-social-outline" size={22} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity onPress={handleGeneratePDF} style={styles.iconBtn} disabled={generating}>
          {generating
            ? <ActivityIndicator size="small" color="#fff" />
            : <Ionicons name="document-text-outline" size={22} color="#fff" />}
        </TouchableOpacity>
      </View>

      {loading ? (
        <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 60 }} />
      ) : cases.length === 0 ? (
        <View style={styles.emptyState}>
          <Ionicons name="scale-outline" size={72} color="#ddd" />
          <Text style={styles.emptyText}>No cases scheduled</Text>
          <Text style={styles.emptySubText}>Tap + to add a new case entry</Text>
        </View>
      ) : (
        <FlatList
          data={cases}
          keyExtractor={item => String(item.id)}
          renderItem={({ item }) => (
            <CaseCard
              entry={item}
              dateKey={dateKey}
              onSave={handleSaveCase}
              onDelete={() => handleDeleteCase(item.id)}
            />
          )}
          contentContainerStyle={{ padding: 12, paddingBottom: 100 }}
          ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
        />
      )}

      <TouchableOpacity style={styles.fab} onPress={handleAddCase}>
        <Ionicons name="add" size={28} color="#fff" />
        <Text style={styles.fabText}>Add Case</Text>
      </TouchableOpacity>
    </View>
  );
}

// ── Case Card ──────────────────────────────────────────────────────────────────
function CaseCard({ entry, dateKey, onSave, onDelete }) {
  const [data, setData] = useState({ ...entry });
  const [expanded, setExpanded] = useState(true);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [saving, setSaving] = useState(false);

  // Sync if parent updates entry
  useCallback(() => { setData({ ...entry }); }, [entry]);

  const update = (field, value) => setData(prev => ({ ...prev, [field]: value }));

  const handleSave = async () => {
    if (data.nextDate && !isValidNextDate(dateKey, data.nextDate)) {
      Alert.alert('Invalid Date', `Next date must be after ${formatDate(dateKey)}`);
      return;
    }
    setSaving(true);
    try {
      await onSave(data);
      Alert.alert('✅ Saved',
        data.nextDate
          ? `Case saved.\nEntry auto-created on ${formatDate(data.nextDate)} with all details.`
          : 'Case saved successfully.'
      );
    } catch (e) { Alert.alert('Error', 'Save failed.'); }
    finally { setSaving(false); }
  };

  const handleDateConfirm = (event, selectedDate) => {
    setShowDatePicker(false);
    if (selectedDate && event.type !== 'dismissed') {
      const d = selectedDate;
      const key = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
      update('nextDate', key);
    }
  };

  return (
    <View style={styles.card}>
      {/* Header row */}
      <View style={styles.cardHeader}>
        <View style={styles.srBadge}>
          <Text style={styles.srText}>Sr. {data.serialNo}</Text>
        </View>
        {!!data.previousDate && (
          <View style={styles.linkedBadge}>
            <Ionicons name="link" size={11} color="#2E7D32" />
            <Text style={styles.linkedText}> from {formatDate(data.previousDate)}</Text>
          </View>
        )}
        <View style={{ flex: 1 }} />
        <TouchableOpacity onPress={() => setExpanded(e => !e)} style={{ padding: 6 }}>
          <Ionicons name={expanded ? 'chevron-up' : 'chevron-down'} size={20} color="#666" />
        </TouchableOpacity>
        <TouchableOpacity onPress={onDelete} style={{ padding: 6 }}>
          <Ionicons name="trash-outline" size={20} color={COLORS.error} />
        </TouchableOpacity>
      </View>

      {expanded && (
        <View style={styles.cardBody}>
          <Field label="Court Name" value={data.courtName} onChange={v => update('courtName', v)} icon="business-outline" />

          <View style={{ flexDirection: 'row', gap: 8 }}>
            <View style={{ flex: 1 }}>
              <Field label="Plaintiff" value={data.plaintiffName} onChange={v => update('plaintiffName', v)} icon="person-outline" />
            </View>
            <Text style={styles.vsText}>vs</Text>
            <View style={{ flex: 1 }}>
              <Field label="Defendant" value={data.defendantName} onChange={v => update('defendantName', v)} />
            </View>
          </View>

          <View style={{ flexDirection: 'row', gap: 8 }}>
            <View style={{ flex: 1 }}>
              <Field label="Case No." value={data.caseNo} onChange={v => update('caseNo', v)} />
            </View>
            <View style={{ flex: 0.55 }}>
              <Field label="Year" value={data.caseYear} onChange={v => update('caseYear', v)} keyboardType="numeric" />
            </View>
          </View>

          <Field label="Police Station" value={data.policeStation} onChange={v => update('policeStation', v)} icon="shield-outline" />

          {!!data.previousDate && (
            <View style={styles.readonlyField}>
              <Ionicons name="calendar-outline" size={15} color="#999" />
              <View style={{ marginLeft: 8 }}>
                <Text style={styles.readonlyLabel}>Previous Date</Text>
                <Text style={styles.readonlyValue}>{formatDate(data.previousDate)}</Text>
              </View>
            </View>
          )}

          <Field label="Next Proceedings" value={data.nextProceedings}
            onChange={v => update('nextProceedings', v)} multiline numberOfLines={3} />

          {/* Next Date picker */}
          <TouchableOpacity style={styles.datePicker} onPress={() => setShowDatePicker(true)}>
            <Ionicons name="calendar" size={20} color={COLORS.primary} />
            <View style={{ flex: 1, marginLeft: 10 }}>
              <Text style={styles.datePickerLabel}>Next Hearing Date</Text>
              <Text style={[styles.datePickerValue, !data.nextDate && { color: '#bbb' }]}>
                {data.nextDate ? formatDate(data.nextDate) : 'Tap to select date'}
              </Text>
            </View>
            {!!data.nextDate && (
              <TouchableOpacity onPress={() => update('nextDate', '')}>
                <Ionicons name="close-circle" size={20} color="#999" />
              </TouchableOpacity>
            )}
          </TouchableOpacity>

          {showDatePicker && (
            <DateTimePicker
              value={data.nextDate ? new Date(data.nextDate) : new Date()}
              mode="date"
              minimumDate={new Date(dateKey)}
              onChange={handleDateConfirm}
            />
          )}

          {data.futureEntryCreated && !!data.nextDate && (
            <View style={styles.linkedInfo}>
              <Ionicons name="checkmark-circle" size={14} color="#2E7D32" />
              <Text style={styles.linkedInfoText}>
                {' '}All details auto-copied to {formatDate(data.nextDate)}
              </Text>
            </View>
          )}

          <TouchableOpacity style={styles.saveBtn} onPress={handleSave} disabled={saving}>
            {saving
              ? <ActivityIndicator size="small" color="#fff" />
              : <><Ionicons name="save-outline" size={18} color="#fff" />
                 <Text style={styles.saveBtnText}> Save Entry</Text></>
            }
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

function Field({ label, value, onChange, icon, multiline, numberOfLines, keyboardType }) {
  return (
    <View style={{ marginBottom: 10 }}>
      <Text style={{ fontSize: 11, color: '#888', marginBottom: 3 }}>{label}</Text>
      <View style={{ flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: '#ddd', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 7, backgroundColor: '#fafafa' }}>
        {icon ? <Ionicons name={icon} size={15} color="#bbb" style={{ marginRight: 6 }} /> : null}
        <TextInput
          style={[{ flex: 1, fontSize: 14, color: '#1a1a1a' }, multiline && { height: 72, textAlignVertical: 'top' }]}
          value={value || ''}
          onChangeText={onChange}
          placeholder={label}
          placeholderTextColor="#ccc"
          multiline={multiline}
          numberOfLines={numberOfLines}
          keyboardType={keyboardType || 'default'}
          autoCapitalize="words"
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F9' },
  header: { backgroundColor: '#1A237E', paddingTop: 48, paddingBottom: 14, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center' },
  backBtn: { marginRight: 10, padding: 4 },
  headerDate: { color: '#fff', fontSize: 17, fontWeight: 'bold' },
  headerSub: { color: 'rgba(255,255,255,0.75)', fontSize: 12 },
  caseCount: { color: 'rgba(255,255,255,0.8)', fontSize: 13, marginRight: 4 },
  iconBtn: { padding: 8 },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  emptyText: { fontSize: 17, color: '#aaa', marginTop: 14 },
  emptySubText: { fontSize: 13, color: '#ccc', marginTop: 4 },
  fab: { position: 'absolute', bottom: 24, right: 20, backgroundColor: '#1A237E', flexDirection: 'row', alignItems: 'center', paddingVertical: 14, paddingHorizontal: 22, borderRadius: 30, elevation: 6 },
  fabText: { color: '#fff', fontWeight: 'bold', marginLeft: 6, fontSize: 15 },
  card: { backgroundColor: '#fff', borderRadius: 12, elevation: 2 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', padding: 12, borderBottomWidth: 1, borderBottomColor: '#f5f5f5' },
  srBadge: { backgroundColor: '#E8EAF6', borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3 },
  srText: { color: '#1A237E', fontSize: 12, fontWeight: 'bold' },
  linkedBadge: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#E8F5E9', borderRadius: 6, paddingHorizontal: 6, paddingVertical: 3, marginLeft: 8 },
  linkedText: { color: '#2E7D32', fontSize: 11 },
  cardBody: { padding: 14 },
  vsText: { color: '#1A237E', fontWeight: 'bold', alignSelf: 'center', marginTop: 14, marginHorizontal: 2 },
  readonlyField: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#f5f5f5', borderRadius: 8, padding: 10, marginBottom: 10 },
  readonlyLabel: { fontSize: 11, color: '#999' },
  readonlyValue: { fontSize: 14, color: '#555' },
  datePicker: { flexDirection: 'row', alignItems: 'center', borderWidth: 1.5, borderColor: '#1A237E', borderRadius: 8, padding: 12, marginBottom: 10 },
  datePickerLabel: { fontSize: 11, color: '#888' },
  datePickerValue: { fontSize: 14, color: '#1a1a1a', marginTop: 2 },
  linkedInfo: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#E8F5E9', borderRadius: 8, padding: 8, marginBottom: 10 },
  linkedInfoText: { fontSize: 12, color: '#2E7D32', flex: 1 },
  saveBtn: { backgroundColor: '#1A237E', borderRadius: 8, padding: 14, alignItems: 'center', flexDirection: 'row', justifyContent: 'center', marginTop: 4 },
  saveBtnText: { color: '#fff', fontWeight: 'bold', fontSize: 15 },
});
