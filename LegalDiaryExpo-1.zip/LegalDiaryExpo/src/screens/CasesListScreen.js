import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, FlatList } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { formatDate } from '../utils/helpers';

export default function CasesListScreen({ route, navigation }) {
  const { cases, title } = route.params;

  const renderCase = ({ item, index }) => (
    <TouchableOpacity
      style={styles.caseCard}
      onPress={() => navigation.navigate('DailyEntry', { dateKey: item.dateKey })}
    >
      <View style={styles.indexBadge}>
        <Text style={styles.indexText}>{index + 1}</Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.courtName}>{item.courtName || 'Court not set'}</Text>
        <Text style={styles.parties} numberOfLines={1}>
          {item.plaintiffName || '?'} vs {item.defendantName || '?'}
        </Text>
        <View style={styles.metaRow}>
          <Text style={styles.meta}>
            <Ionicons name="document-outline" size={11} /> {item.caseNo || '—'}/{item.caseYear || '—'}
          </Text>
          <Text style={styles.meta}>
            <Ionicons name="calendar-outline" size={11} /> {formatDate(item.dateKey)}
          </Text>
        </View>
        {item.nextDate ? (
          <View style={styles.nextDateBadge}>
            <Ionicons name="arrow-forward-circle" size={13} color="#1A237E" />
            <Text style={styles.nextDateText}> Next: {formatDate(item.nextDate)}</Text>
          </View>
        ) : (
          <View style={[styles.nextDateBadge, { backgroundColor: '#FFF3E0' }]}>
            <Ionicons name="time-outline" size={13} color="#E65100" />
            <Text style={[styles.nextDateText, { color: '#E65100' }]}> No next date set</Text>
          </View>
        )}
      </View>
      <Ionicons name="chevron-forward" size={18} color="#ccc" />
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={{ padding: 4, marginRight: 12 }}>
          <Ionicons name="arrow-back" size={24} color="#fff" />
        </TouchableOpacity>
        <View>
          <Text style={styles.headerTitle}>{title}</Text>
          <Text style={styles.headerSub}>{cases.length} case{cases.length !== 1 ? 's' : ''} found</Text>
        </View>
      </View>

      {cases.length === 0 ? (
        <View style={styles.emptyState}>
          <Ionicons name="scale-outline" size={60} color="#ccc" />
          <Text style={styles.emptyText}>No cases found</Text>
        </View>
      ) : (
        <FlatList
          data={cases}
          keyExtractor={item => String(item.id)}
          renderItem={renderCase}
          contentContainerStyle={{ padding: 12, paddingBottom: 30 }}
          ItemSeparatorComponent={() => <View style={{ height: 8 }} />}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F9' },
  header: { backgroundColor: '#1A237E', paddingTop: 50, paddingBottom: 14, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center' },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  headerSub: { color: 'rgba(255,255,255,0.7)', fontSize: 12 },
  caseCard: { backgroundColor: '#fff', borderRadius: 12, padding: 14, flexDirection: 'row', alignItems: 'center', elevation: 1 },
  indexBadge: { width: 32, height: 32, borderRadius: 16, backgroundColor: '#E8EAF6', alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  indexText: { color: '#1A237E', fontWeight: 'bold', fontSize: 13 },
  courtName: { fontSize: 14, fontWeight: '700', color: '#1a1a1a', marginBottom: 2 },
  parties: { fontSize: 13, color: '#444', marginBottom: 4 },
  metaRow: { flexDirection: 'row', gap: 12, marginBottom: 6 },
  meta: { fontSize: 11, color: '#888' },
  nextDateBadge: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#E8EAF6', borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3, alignSelf: 'flex-start' },
  nextDateText: { fontSize: 12, color: '#1A237E' },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  emptyText: { fontSize: 16, color: '#aaa', marginTop: 12 },
});
