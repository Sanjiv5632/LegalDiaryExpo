import React, { useState, useEffect } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, FlatList,
  ActivityIndicator, Alert
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getMonthlySummary, getCasesForDate } from '../database/Repository';
import { generateMonthlyPDF } from '../utils/pdfGenerator';
import { formatDate, getMonthName } from '../utils/helpers';
import * as DB from '../database/Database';

export default function MonthlyViewScreen({ route, navigation }) {
  const { yearMonth } = route.params;
  const [year, month] = yearMonth.split('-');
  const [summary, setSummary] = useState([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [totalCases, setTotalCases] = useState(0);

  useEffect(() => { loadData(); }, [yearMonth]);

  const loadData = async () => {
    setLoading(true);
    try {
      const data = await getMonthlySummary(yearMonth);
      setSummary(data);
      setTotalCases(data.reduce((s, d) => s + d.caseCount, 0));
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  // Feature 3: Generate monthly PDF
  const handleMonthlyPDF = async () => {
    setGenerating(true);
    try {
      // Fetch all cases for the month
      const allCases = [];
      for (const row of summary) {
        const dayCases = await getCasesForDate(row.dateKey);
        allCases.push(...dayCases);
      }
      await generateMonthlyPDF(yearMonth, summary, allCases);
    } catch (e) {
      Alert.alert('Error', 'Could not generate PDF.');
    } finally {
      setGenerating(false);
    }
  };

  const renderDayRow = ({ item }) => {
    const parties = item.parties
      ? item.parties.split(' | ').slice(0, 2).join('\n') + (item.parties.split(' | ').length > 2 ? '\n...' : '')
      : '—';

    return (
      <TouchableOpacity
        style={styles.dayRow}
        onPress={() => navigation.navigate('DailyEntry', { dateKey: item.dateKey })}
      >
        <View style={styles.dateBox}>
          <Text style={styles.dateBoxDay}>{item.dateKey.split('-')[2]}</Text>
          <Text style={styles.dateBoxMon}>{getMonthName(item.dateKey.split('-')[1]).substring(0, 3)}</Text>
        </View>
        <View style={styles.dayContent}>
          <Text style={styles.partyText} numberOfLines={2}>{parties}</Text>
        </View>
        <View style={styles.countBadge}>
          <Text style={styles.countText}>{item.caseCount}</Text>
          <Text style={styles.countLabel}>cases</Text>
        </View>
        <Ionicons name="chevron-forward" size={16} color="#ccc" />
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={{ padding: 4, marginRight: 10 }}>
          <Ionicons name="arrow-back" size={24} color="#fff" />
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>{getMonthName(month)} {year}</Text>
          <Text style={styles.headerSub}>Monthly Case Report</Text>
        </View>
        <TouchableOpacity onPress={handleMonthlyPDF} style={styles.pdfBtn} disabled={generating}>
          {generating
            ? <ActivityIndicator size="small" color="#fff" />
            : <><Ionicons name="document-text" size={18} color="#fff" /><Text style={styles.pdfBtnText}> PDF</Text></>
          }
        </TouchableOpacity>
      </View>

      {/* Stats summary */}
      <View style={styles.summaryBar}>
        <View style={styles.summaryItem}>
          <Text style={styles.summaryNum}>{summary.length}</Text>
          <Text style={styles.summaryLabel}>Hearing Days</Text>
        </View>
        <View style={styles.summaryDivider} />
        <View style={styles.summaryItem}>
          <Text style={styles.summaryNum}>{totalCases}</Text>
          <Text style={styles.summaryLabel}>Total Cases</Text>
        </View>
        <View style={styles.summaryDivider} />
        <View style={styles.summaryItem}>
          <Text style={styles.summaryNum}>
            {summary.length > 0 ? (totalCases / summary.length).toFixed(1) : '0'}
          </Text>
          <Text style={styles.summaryLabel}>Avg/Day</Text>
        </View>
      </View>

      {loading ? (
        <ActivityIndicator size="large" color="#1A237E" style={{ marginTop: 40 }} />
      ) : summary.length === 0 ? (
        <View style={styles.emptyState}>
          <Ionicons name="calendar-outline" size={60} color="#ccc" />
          <Text style={styles.emptyText}>No cases in {getMonthName(month)} {year}</Text>
        </View>
      ) : (
        <FlatList
          data={summary}
          keyExtractor={item => item.dateKey}
          renderItem={renderDayRow}
          contentContainerStyle={{ paddingBottom: 30 }}
          ItemSeparatorComponent={() => <View style={{ height: 1, backgroundColor: '#f0f0f0', marginLeft: 70 }} />}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F9' },
  header: { backgroundColor: '#1A237E', paddingTop: 50, paddingBottom: 14, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center' },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  headerSub: { color: 'rgba(255,255,255,0.7)', fontSize: 12 },
  pdfBtn: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(255,255,255,0.2)', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20 },
  pdfBtnText: { color: '#fff', fontWeight: 'bold', fontSize: 14 },
  summaryBar: { flexDirection: 'row', backgroundColor: '#fff', margin: 12, borderRadius: 12, elevation: 2 },
  summaryItem: { flex: 1, alignItems: 'center', paddingVertical: 14 },
  summaryNum: { fontSize: 22, fontWeight: 'bold', color: '#1A237E' },
  summaryLabel: { fontSize: 11, color: '#999', marginTop: 2 },
  summaryDivider: { width: 1, backgroundColor: '#f0f0f0', marginVertical: 10 },
  dayRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', paddingHorizontal: 14, paddingVertical: 12 },
  dateBox: { width: 44, alignItems: 'center', backgroundColor: '#E8EAF6', borderRadius: 8, paddingVertical: 4 },
  dateBoxDay: { fontSize: 18, fontWeight: 'bold', color: '#1A237E' },
  dateBoxMon: { fontSize: 10, color: '#666' },
  dayContent: { flex: 1, marginHorizontal: 12 },
  partyText: { fontSize: 13, color: '#333', lineHeight: 18 },
  countBadge: { alignItems: 'center', marginRight: 8 },
  countText: { fontSize: 20, fontWeight: 'bold', color: '#1A237E' },
  countLabel: { fontSize: 10, color: '#999' },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  emptyText: { fontSize: 16, color: '#aaa', marginTop: 12 },
});
