import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView,
  FlatList, Alert, ActivityIndicator
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { getAllDatesWithCases, getTotalCasesCount, getActiveCasesCount,
         getAllCasesList, getActiveCasesList } from '../database/Repository';
import { todayKey, formatDate, getMonthName } from '../utils/helpers';

const COLORS = {
  primary: '#1A237E', primaryLight: '#3949AB', gold: '#FFB300',
  surface: '#fff', background: '#F3F4F9', text: '#1a1a1a',
  textLight: '#666', border: '#E0E0E0', error: '#C62828',
};
const WEEKDAYS = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

export default function CalendarScreen({ navigation }) {
  const today = todayKey();
  const [year, setYear] = useState(new Date().getFullYear());
  const [datesWithCases, setDatesWithCases] = useState(new Set());
  const [stats, setStats] = useState({ total: 0, active: 0 });
  const [loading, setLoading] = useState(true);

  // Reload whenever screen is focused
  useFocusEffect(useCallback(() => {
    loadData();
  }, [year]));

  const loadData = async () => {
    setLoading(true);
    try {
      const [dates, total, active] = await Promise.all([
        getAllDatesWithCases(),
        getTotalCasesCount(),
        getActiveCasesCount(),
      ]);
      setDatesWithCases(new Set(dates));
      setStats({ total, active });
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  // Feature 5: Show cases list on stats tap
  const handleStatsTap = async (type) => {
    try {
      const cases = type === 'active'
        ? await getActiveCasesList()
        : await getAllCasesList();

      if (cases.length === 0) {
        Alert.alert(type === 'active' ? 'Active Cases' : 'All Cases', 'No cases found.');
        return;
      }
      navigation.navigate('CasesList', { cases, title: type === 'active' ? 'Active Cases' : 'All Cases' });
    } catch (e) {
      Alert.alert('Error', 'Could not load cases.');
    }
  };

  const months = Array.from({ length: 12 }, (_, i) => i + 1);

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.appTitle}>⚖️ LegalDiary</Text>

        {/* Stats Row — Feature 5 */}
        <View style={styles.statsRow}>
          <TouchableOpacity style={styles.statBox} onPress={() => handleStatsTap('total')}>
            <Text style={styles.statNum}>{stats.total}</Text>
            <Text style={styles.statLabel}>Total Cases</Text>
          </TouchableOpacity>
          <View style={styles.statDivider} />
          <TouchableOpacity style={styles.statBox} onPress={() => handleStatsTap('active')}>
            <Text style={[styles.statNum, { color: '#FFB300' }]}>{stats.active}</Text>
            <Text style={styles.statLabel}>Active Cases</Text>
          </TouchableOpacity>
        </View>

        {/* Year navigation */}
        <View style={styles.yearNav}>
          <TouchableOpacity onPress={() => setYear(y => y - 1)} style={styles.arrowBtn}>
            <Ionicons name="chevron-back" size={22} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.yearText}>{year}</Text>
          <TouchableOpacity onPress={() => setYear(y => y + 1)} style={styles.arrowBtn}>
            <Ionicons name="chevron-forward" size={22} color="#fff" />
          </TouchableOpacity>
          {year !== new Date().getFullYear() && (
            <TouchableOpacity onPress={() => setYear(new Date().getFullYear())} style={styles.todayBtn}>
              <Ionicons name="today-outline" size={18} color="#fff" />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {loading ? (
        <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 40 }} />
      ) : (
        <ScrollView contentContainerStyle={{ paddingBottom: 30 }}>
          {months.map(month => (
            <MonthCard
              key={month}
              year={year}
              month={month}
              today={today}
              datesWithCases={datesWithCases}
              onDayPress={(dateKey) => navigation.navigate('DailyEntry', { dateKey })}
              onMonthPress={(ym) => navigation.navigate('MonthlyView', { yearMonth: ym })}
            />
          ))}
        </ScrollView>
      )}
    </View>
  );
}

// ── Month Card ─────────────────────────────────────────────────────────────────
function MonthCard({ year, month, today, datesWithCases, onDayPress, onMonthPress }) {
  const monthStr = String(month).padStart(2, '0');
  const yearMonth = `${year}-${monthStr}`;
  const firstDay = new Date(year, month - 1, 1);
  const daysInMonth = new Date(year, month, 0).getDate();
  const offset = firstDay.getDay(); // 0=Sun
  const totalCells = offset + daysInMonth;
  const rows = Math.ceil(totalCells / 7);

  return (
    <View style={styles.card}>
      {/* Month header */}
      <TouchableOpacity
        style={styles.monthHeader}
        onPress={() => onMonthPress(yearMonth)}
      >
        <Text style={styles.monthTitle}>{getMonthName(monthStr)} {year}</Text>
        <Ionicons name="bar-chart-outline" size={16} color={COLORS.primary} />
      </TouchableOpacity>

      {/* Weekday labels */}
      <View style={styles.weekRow}>
        {WEEKDAYS.map(d => (
          <Text key={d} style={styles.weekLabel}>{d}</Text>
        ))}
      </View>

      {/* Day grid */}
      {Array.from({ length: rows }, (_, row) => (
        <View key={row} style={styles.weekRow}>
          {Array.from({ length: 7 }, (_, col) => {
            const dayNum = row * 7 + col - offset + 1;
            if (dayNum < 1 || dayNum > daysInMonth) return <View key={col} style={styles.dayCell} />;
            const dateKey = `${year}-${monthStr}-${String(dayNum).padStart(2, '0')}`;
            const isToday = dateKey === today;
            const hasCases = datesWithCases.has(dateKey);
            const isPast = dateKey < today;
            return (
              <TouchableOpacity
                key={col}
                style={[styles.dayCell, isToday && styles.todayCell]}
                onPress={() => onDayPress(dateKey)}
              >
                <Text style={[
                  styles.dayNum,
                  isToday && styles.todayNum,
                  isPast && !isToday && styles.pastNum,
                ]}>
                  {dayNum}
                </Text>
                {hasCases && (
                  <View style={[styles.dot, isToday && styles.dotOnToday]} />
                )}
              </TouchableOpacity>
            );
          })}
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  header: { backgroundColor: COLORS.primary, paddingTop: 50, paddingBottom: 12, paddingHorizontal: 16 },
  appTitle: { color: '#fff', fontSize: 22, fontWeight: 'bold', marginBottom: 10 },
  statsRow: { flexDirection: 'row', backgroundColor: 'rgba(255,255,255,0.15)', borderRadius: 12, marginBottom: 12 },
  statBox: { flex: 1, alignItems: 'center', paddingVertical: 10 },
  statNum: { color: '#fff', fontSize: 24, fontWeight: 'bold' },
  statLabel: { color: 'rgba(255,255,255,0.8)', fontSize: 12 },
  statDivider: { width: 1, backgroundColor: 'rgba(255,255,255,0.3)', marginVertical: 8 },
  yearNav: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  arrowBtn: { padding: 8 },
  yearText: { color: '#fff', fontSize: 22, fontWeight: 'bold', marginHorizontal: 20 },
  todayBtn: { marginLeft: 12, padding: 6 },
  card: { backgroundColor: '#fff', margin: 8, marginBottom: 4, borderRadius: 12, padding: 12, elevation: 2 },
  monthHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  monthTitle: { color: COLORS.primary, fontSize: 15, fontWeight: '700' },
  weekRow: { flexDirection: 'row' },
  weekLabel: { flex: 1, textAlign: 'center', color: '#999', fontSize: 11, paddingVertical: 2 },
  dayCell: { flex: 1, aspectRatio: 1, alignItems: 'center', justifyContent: 'center' },
  todayCell: { backgroundColor: COLORS.primary, borderRadius: 50 },
  dayNum: { fontSize: 13, color: COLORS.text },
  todayNum: { color: '#fff', fontWeight: 'bold' },
  pastNum: { color: '#bbb' },
  dot: { width: 4, height: 4, borderRadius: 2, backgroundColor: COLORS.primary, marginTop: 1 },
  dotOnToday: { backgroundColor: '#fff' },
});
