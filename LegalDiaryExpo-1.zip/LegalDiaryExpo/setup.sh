#!/bin/bash
# ── LegalDiary Expo — Termux Setup Script ─────────────────────────────────────
# Run this script step by step in Termux

echo "╔══════════════════════════════════════════╗"
echo "║    LegalDiary — Termux Build Setup       ║"
echo "╚══════════════════════════════════════════╝"

# Step 1: Update packages
echo ""
echo "▶ Step 1: Updating Termux packages..."
pkg update -y && pkg upgrade -y

# Step 2: Install Node.js
echo ""
echo "▶ Step 2: Installing Node.js..."
pkg install nodejs-lts -y

# Step 3: Install git
echo ""
echo "▶ Step 3: Installing Git..."
pkg install git -y

# Step 4: Install EAS CLI
echo ""
echo "▶ Step 4: Installing EAS CLI..."
npm install -g eas-cli expo-cli

# Step 5: Go to project folder
echo ""
echo "▶ Step 5: Enter project directory"
echo "   Run: cd LegalDiaryExpo"

# Step 6: Install dependencies
echo ""
echo "▶ Step 6: Install project dependencies"
echo "   Run: npm install"

# Step 7: Login to Expo
echo ""
echo "▶ Step 7: Login to Expo account"
echo "   Run: eas login"
echo "   (Enter your expo.dev email and password)"

# Step 8: Build APK
echo ""
echo "▶ Step 8: Build APK (uploads to expo.dev — takes 5-10 min)"
echo "   Run: eas build --platform android --profile preview"

echo ""
echo "✅ Follow steps 5-8 manually after running this script!"
