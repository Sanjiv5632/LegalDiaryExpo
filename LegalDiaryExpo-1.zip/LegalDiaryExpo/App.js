import React, { useEffect, useRef } from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import * as Notifications from 'expo-notifications';

import CalendarScreen    from './src/screens/CalendarScreen';
import DailyEntryScreen  from './src/screens/DailyEntryScreen';
import MonthlyViewScreen from './src/screens/MonthlyViewScreen';
import CasesListScreen   from './src/screens/CasesListScreen';

import {
  scheduleDailyReminder,
  setupNotificationChannel,
  sendTomorrowCaseNotifications,
} from './src/utils/NotificationService';

const Stack = createStackNavigator();

export default function App() {
  const navigationRef = useRef(null);
  const notificationListener = useRef();
  const responseListener = useRef();

  useEffect(() => {
    const initNotifications = async () => {
      await setupNotificationChannel();
      await scheduleDailyReminder();
    };
    initNotifications();

    notificationListener.current = Notifications.addNotificationReceivedListener(
      async (notification) => {
        if (notification.request.content.data?.type === 'daily_reminder') {
          await sendTomorrowCaseNotifications();
        }
      }
    );

    responseListener.current = Notifications.addNotificationResponseReceivedListener(
      (response) => {
        const data = response.notification.request.content.data;
        if (data?.dateKey && navigationRef.current) {
          navigationRef.current.navigate('DailyEntry', { dateKey: data.dateKey });
        }
      }
    );

    return () => {
      Notifications.removeNotificationSubscription(notificationListener.current);
      Notifications.removeNotificationSubscription(responseListener.current);
    };
  }, []);

  return (
    <NavigationContainer ref={navigationRef}>
      <StatusBar style="light" />
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Calendar"     component={CalendarScreen} />
        <Stack.Screen name="DailyEntry"   component={DailyEntryScreen} />
        <Stack.Screen name="MonthlyView"  component={MonthlyViewScreen} />
        <Stack.Screen name="CasesList"    component={CasesListScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
